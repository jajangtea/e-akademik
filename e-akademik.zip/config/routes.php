<?php
/**
 * @author : Chabib Nurozak <chabibnurozak@gmail.com>
 * @website: chabibnr.net
 * @created: 9/28/2017
 * @file   : routes.php
 */

return [

];