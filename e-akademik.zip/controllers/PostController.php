<?php
/**
 * Created by PhpStorm.
 * User: Butterfly
 * Date: 10/2/2017
 * Time: 10:13 AM
 */

namespace app\controllers;


use yii\web\Controller;

class PostController extends Controller
{
    public function actionIndex(){

    }
}