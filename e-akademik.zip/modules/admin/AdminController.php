<?php
/**
 * Created by PhpStorm.
 * User: Butterfly
 * Date: 10/2/2017
 * Time: 3:50 PM
 */

namespace app\modules\admin;


use yii\web\Controller;

class AdminController extends Controller
{
    public $layout = 'main';
}