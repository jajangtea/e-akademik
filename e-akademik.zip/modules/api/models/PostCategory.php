<?php
/**
 * Created by PhpStorm.
 * User: Butterfly
 * Date: 10/7/2017
 * Time: 1:40 PM
 */

namespace app\modules\api\models;


use app\models\BasePostCategory;

class PostCategory extends BasePostCategory
{

}