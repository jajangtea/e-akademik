<?php
/**
 * Created by PhpStorm.
 * User: Butterfly
 * Date: 10/5/2017
 * Time: 11:49 AM
 */

namespace app\models;


class OauthAuthorizationCode extends BaseOauthAuthorizationCode
{

}